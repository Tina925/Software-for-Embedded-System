The hardware set up for this lab is just connecting the esp43 board to my laptop

https://www.youtube.com/watch?v=vuJTQmGs_ro&ab_channel=mengtingxu