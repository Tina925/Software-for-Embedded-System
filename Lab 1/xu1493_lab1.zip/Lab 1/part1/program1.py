name = input("What is your name? ")
print(name)
age = input ("How old are you? ")
print(age)
yearLeft = 100 - int(age)
year = yearLeft + 2023
print(name + " will be 100 years old in " + str(year))

